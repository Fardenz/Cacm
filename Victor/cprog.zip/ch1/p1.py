memo = {}

def max_cycle_length(i,j):
    if i > j:
        return max_cycle_length(j,i)
    else:
        max_c = -1
        for n in range(i, j+1):
            aux = cycle_length(n)
            if aux > max_c:
                max_c = aux
        return max_c
        

def cycle_length(n):
    if n == 1:
        return 1
    res = memo.get(n,-1)
    if res == -1:
        if n % 2 == 0:
            res = cycle_length(n/2) + 1
        else:
            res = cycle_length(3*n+1) + 1
        memo[n] = res
    return res
            
inps = list(map(int,input().split()))
while len(inps) == 2:
    res = max_cycle_length(inps[0],inps[1])
    print(inps[0],inps[1],res)
    try:
        inps = list(map(int,input().split()))
    except:
        break