def neighbours(p):
    yield (p[0],p[1]+1)
    yield (p[0]+1,p[1]+1)
    yield (p[0]+1,p[1])
    yield (p[0]+1,p[1]-1)
    yield (p[0],p[1]-1)
    yield (p[0]-1,p[1]-1)
    yield (p[0]-1,p[1])
    yield (p[0]-1,p[1]+1)

def print_grid(grid,max_x,max_y):
    for y in range(0,max_y):
        for x in range(0,max_x):
            print(grid[(x,y)],end="")
        print("\n",end="")

counter = 1
inps = list(map(int,input().split()))
while inps[0] != 0 and inps[1] != 0:
    grid = {}
    for y in range(0,inps[0]):
        line = list(input())
        for x, value in enumerate(line):
            if value == "*":
                for n in neighbours((x,y)):
                    aux = grid.get(n,0)
                    if aux != "*":
                        grid[n] = aux + 1
                grid[(x,y)] = "*"
            else:
                grid.setdefault((x,y),0)
    print("Field #%d:" % (counter))
    print_grid(grid,inps[1],inps[0])
    counter += 1

    inps = list(map(int,input().split()))
    if inps[0] != 0 and inps[1] != 0:
        print()