cases = int(input())
input()

for case in range(0,cases):
    registers = [0]*10
    ram = [0]*1000

    counter = 0
    aux = input()
    while aux != "":
        ram[counter] = int(aux)
        counter += 1
        try:
            aux = input()
        except:
            break
    
    pc = 0
    res = 0
    try:
        while True:
            com = int(ram[pc]/100)
            arg1 = int(ram[pc]/10)%10
            arg2 = ram[pc]%10

            #print(com,arg1,arg2,registers)

            if com == 1 and arg1 == 0 and arg2 == 0:
                res += 1
                break
            if com == 2:
                registers[arg1] = arg2
            if com == 3:
                registers[arg1] = (registers[arg1] + arg2) % 1000
            if com == 4:
                registers[arg1] = (registers[arg1] * arg2) % 1000
            if com == 5:
                registers[arg1] = registers[arg2]
            if com == 6:
                registers[arg1] = (registers[arg1] + registers[arg2]) % 1000
            if com == 7:
                registers[arg1] = (registers[arg1] * registers[arg2]) % 1000
            if com == 8:
                registers[arg1] = ram[registers[arg2]]
            if com == 9:
                ram[registers[arg2]] = registers[arg1]
            if com == 0:
                if registers[arg2] != 0:
                    pc = registers[arg1]-1

            pc += 1
            res += 1
    except:
        print("Segmentation fault")

    print(res)
    if case != cases-1:
        print()