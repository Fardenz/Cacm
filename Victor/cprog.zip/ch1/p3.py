case = int(input())
while case != 0:
    values = []
    for i in range(0, case):
        values.append(int(float(input())*100))
    media = int(sum(values)/case)
    print(case,values,media)
    result = sum(filter(lambda x: x>0,map(lambda x: x-media,values)))
    print(list(map(lambda x: x-media,values)),result)
    print("$%.2f" % (result/100.0))
    case = int(input())