
memo = []

def max_cycle_length(i,j):
    if i > j:
        return max_cycle_length(j,i)
    else:
        m_i = cycle_length(i)
        m_j = cycle_length(j)
        return max(m_i,m_j)
        

def cycle_length(n):
    pass

inps = list(map(int,input().split()))
while len(inps) == 2:
    res = max_cycle_length(inps[0],inps[1])
    print(inps[0],inps[1],res)
    inps = list(map(int,input().split()))
