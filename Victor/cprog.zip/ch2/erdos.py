erdos = "Erdos, P."
escenarios = int(input())

for e in range(0,escenarios):
    aux = input().split()
    ps = int(aux[0])
    ns = int(aux[1])

    graph = {}
    memo = {}
    for p in range(0,ps):
        aux = input().split(": ")
        paper = aux[1]
        authors = []
        aux = aux[0].split(", ")
        for a in range(0,int(len(aux)/2)):
            a_s = aux[a*2] + ", " + aux[a*2+1]
            authors.append(a_s)
        for a in authors:
            graph[a] = graph.setdefault(a,set()).union(set(authors))
    for a in graph.keys():
        graph[a] = list(graph[a])

    visited = set([erdos])
    active = [erdos]
    next_active = []
    level = 0
    while len(active) > 0:
        while len(active) > 0:
            curr = active.pop()
            memo[curr] = level
            for adj in graph[curr]:
                if adj not in visited:
                    visited.add(adj)
                    next_active.append(adj)
        active = next_active
        next_active = []
        level += 1

    print("Scenario %d" % (e+1))
    for n in range(0,ns):
        name = input()
        print("%s %s" % (name, str(memo.get(name, "infinity"))))
