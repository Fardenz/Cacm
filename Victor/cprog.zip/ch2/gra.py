import sys

def new_board(M,N):
    result = []
    for m in range(0,N):
        result.append(["O"]*M)
    return result

def clear_board(board):
    result = board
    for i in range(0,len(result[0])):
        for j in range(0,len(result)):
            result[j][i] = "O"
    return result

def print_board(board, name):
    print(name)
    for row in board:
        for col in row:
            print(col, end="")
        print("\n", end="")

def neighbours(x,y):
    yield (x,y+1)
    yield (x+1,y)
    yield (x,y-1)
    yield (x-1,y)

board = []

while True:
    aux = input().split()
    try:
        if aux[0] == "I":
            board = new_board(int(aux[1]), int(aux[2]))
        if aux[0] == "C":
            board = clear_board(board)
        if aux[0] == "L":
            board[int(aux[2])-1][int(aux[1])-1] = aux[3]
        if aux[0] == "V":
            y1 = int(aux[2])-1
            y2 = int(aux[3])-1
            if y1 > y2:
                y1, y2 = y2, y1
            for y in range(y1,y2+1):
                board[y][int(aux[1])-1] = aux[4]
        if aux[0] == "H":
            x1 = int(aux[1])-1
            x2 = int(aux[2])-1
            if x1 > x2:
                x1, x2 = x2, x1
            for x in range(x1,x2+1):
                board[int(aux[3])-1][x] = aux[4]
        if aux[0] == "K":
            for x in range(int(aux[1])-1,int(aux[3])):
                for y in range(int(aux[2])-1,int(aux[4])):
                    board[y][x] = aux[5]
        if aux[0] == "F":
            color = board[int(aux[2])-1][int(aux[1])-1]
            queue = [(int(aux[1])-1,int(aux[2])-1)]
            visited = set(queue)
            while len(queue) > 0:
                curr = queue.pop()
                if board[curr[1]][curr[0]] == color:
                    board[curr[1]][curr[0]] = aux[3]
                    for n in neighbours(curr[0],curr[1]):
                        if n not in visited:
                            visited.add(n)
                            if 0 <= n[0] < len(board[0]) and 0 <= n[1] < len(board):
                                queue.insert(0, n)
        if aux[0] == "S":
            print_board(board, aux[1])
        if aux[0] == "X":
            break
    except Exception as e:
        sys.stderr.write(str(e))
        continue