def draw_number(n,s):
    segs = []
    for i in list(str(n)):
        segs.append(get_segments(i))

    for i in range(0,len(str(n))):
        print(" ", end="")
        print(segs[i][0]*s, end="")
        print(" ", end="")
        if i != len(str(n))-1:
            print(" ", end="")
    print("\n", end="")

    for l in range(0,s):
        for i in range(0,len(str(n))):
            print(segs[i][5], end="")
            print(" "*s, end="")
            print(segs[i][1], end="")
            if i != len(str(n))-1:
                print(" ", end="")
        print("\n", end="")

    for i in range(0,len(str(n))):
        print(" ", end="")
        print(segs[i][6]*s, end="")
        print(" ", end="")
        if i != len(str(n))-1:
            print(" ", end="")
    print("\n", end="")

    for l in range(0,s):
        for i in range(0,len(str(n))):
            print(segs[i][4], end="")
            print(" "*s, end="")
            print(segs[i][2], end="")
            if i != len(str(n))-1:
                print(" ", end="")
        print("\n", end="")

    for i in range(0,len(str(n))):
        print(" ", end="")
        print(segs[i][3]*s, end="")
        print(" ", end="")
        if i != len(str(n))-1:
            print(" ", end="")
    print("\n", end="")


def get_segments(n):
    if n == "0":
        return ("-","|","|","-","|","|"," ")
    if n == "1":
        return (" ","|","|"," "," "," "," ")
    if n == "2":
        return ("-","|"," ","-","|"," ","-")
    if n == "3":
        return ("-","|","|","-"," "," ","-")
    if n == "4":
        return (" ","|","|"," "," ","|","-")
    if n == "5":
        return ("-"," ","|","-"," ","|","-")
    if n == "6":
        return ("-"," ","|","-","|","|","-")
    if n == "7":
        return ("-","|","|"," "," "," "," ")
    if n == "8":
        return ("-","|","|","-","|","|","-")
    if n == "9":
        return ("-","|","|","-"," ","|","-")

aux = input().split()
s = int(aux[0])
n = aux[1]
while aux != ["0","0"]:
    draw_number(n,s)
    print("")
    aux = input().split()
    s = int(aux[0])
    n = aux[1]