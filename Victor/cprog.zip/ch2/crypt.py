def back(state,us,ws):
    if len(us) == 0:
        return True
    u = us[0]
    aux_ws = ws[len(u)][:]
    for w in aux_ws:
        if check_possible(u,w,state):
            add_map(u,w,state)
            ws[len(u)].remove(w)
            if back(state,us[1:],ws):
                return True
            remove_map(u,w,state)
            ws[len(u)].append(w)
    return False
    

def check_possible(enc,dec,data):
    pass

def add_map(enc,dec,data):
    pass

def remove_map(enc,dec,data):
    pass

def apply_map(s,data):
    print(data.get(s[0],"*"*len(s[0])), end="")
    for c in s[1:]:
        print(" "+data.get(c,"*"*len(c)), end="")
    print("\n", end="")

n_words = int(input())

words = {}
for w in range(n_words):
    aux = input()
    words.setdefault(len(aux),[]).append(aux)

aux = input()
try:
    while aux != "":
        sentence = aux.split()
        unk = list(set(sentence))
        state = ({},{})

        if len(unk) > n_words:
            apply_map(sentence,state[0])
            aux = input()
            continue

        back(state,unk,words)

        aux = input()
except Exception as e:
    print(e)
    pass