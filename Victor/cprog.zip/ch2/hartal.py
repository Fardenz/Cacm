holidays = [5,6]

cases = int(input())
for case in range(0,cases):
    days = int(input())
    n_parties = int(input())
    params = []
    for p in range(0,n_parties):
        params.append(int(input()))
    strikes = [1 if d%7 not in holidays and any(d%h==h-1 for h in params) else 0 for d in range(0,days)]
    #print(case,days,params)
    #print(strikes)
    print(sum(strikes))