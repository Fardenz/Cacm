def is_sorted(l):
    return all(l[i] >= l[i+1] for i in range(len(l)-1))

def flip(l,n):
    for i in range(0,int((len(l)-n)/2)):
        #print("swap",i,len(l)-1-i)
        l[i+n], l[len(l)-1-i] = l[len(l)-1-i], l[i+n]

while True:
    try:
        stack = list(map(int,reversed(input().split())))
    except:
        break
    original = " ".join(reversed(list(map(str,stack))))
    steps = []
    elem = 0
    while not is_sorted(stack):
        #print(stack)
        #print(steps)
        val, idx = max((stack[i],i) for i in range(elem,len(stack)))
        if idx != elem:
            if idx != len(stack)-1:
                flip(stack,idx)
                steps.append(idx)
            flip(stack,elem)
            steps.append(elem)
        elem += 1
    steps.append(-1)
    print(original)
    print(" ".join(map(lambda x: str(x+1),steps)))