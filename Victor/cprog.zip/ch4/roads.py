cases = int(input())
input()
for case in range(cases):
    prices = list(map(int,input().split()))
    
    records = []
    photo = input()
    while photo != "":
        aux = photo.split(" ")
        aux[1] = list(map(int,aux[1].split(":")))[1:]
        aux[3] = int(aux[3])
        records.append((aux[1][0]*(3600*24)+aux[1][1]*3600+aux[1][2]*60,aux))
        try:
            photo = input()
        except:
            break
    records.sort(key=lambda x: x[0])
    state = {}
    for record in records:
        record = record[1]
        car = state.setdefault(record[0], [0,-1,-1])
        if record[2] == "enter" and car[1] < 0:
            car[1] = prices[record[1][1]]
            car[2] = record[3]
        elif record[2] == "enter" and car[1] > 0:
            car[1] = prices[record[1][1]]
            car[2] = record[3]
        elif record[2] == "exit" and car[1] > 0:
            car[0] += car[1]*abs(car[2]-record[3])+100
            car[1] = -1
            car[2] = -1
    finals = []
    for (plate,record) in state.items():
        if record[0] > 0:
            record[0] += 200
            finals.append(plate)

    for plate in sorted(finals):
        print("%s $%.2f" % (plate, state[plate][0]/100))
    
    if case != cases - 1:
        print()