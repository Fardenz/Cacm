cases = int(input())

for case in range(cases):
    input()
    n_jobs = int(input())
    jobs = {}
    for job in range(n_jobs):
        jobs[job+1] = list(map(int,input().split()))
    res = []
    cost = 0
    days = 0
    for i in range(n_jobs):
        aux = []
        for job in jobs.items():
            aux.append((job[0], job[1][0]/job[1][1]))
        aux.sort(key=lambda x: x[1])
        #print(aux)
        days+=jobs[aux[0][0]][0]
        cost += aux[0][1]
        res.append(aux[0][0])
        del jobs[aux[0][0]]
    #print(res,cost,days)
    print(" ".join(list(map(str,res))))
    if case != cases-1:
        print()

    #            aux.append((job[0], job[1][1]*days+sum([job[1][0]*p[1] for (i,p) in jobs.items() if i != job[0]])))