from math import gcd

case = list(map(int,input().split()))
while case != []:
    n, m = case[0], case[1]
    if m == 0 or (n == 0 and m == 1) or n > m:
        print("%d divides %d!" % (case[1],case[0]))
        try:
            case = list(map(int,input().split()))
        except:
            break
        continue
    
    counter = 1
    acc = 1
    acc2 = n
    aux = m
    aux2 = m
    flag = False
    while counter <= n:
        acc *= counter
        if acc%aux == 0:
            flag = True
            break
        #print(counter,acc,aux)
        d = gcd(acc,aux)
        #print(d)
        acc = acc//d
        aux = aux//d
        d = gcd(acc2,aux2)
        acc2 = acc2//d
        aux2 = aux2//d
        if acc2%aux2 == 0:
            flag = True
            break
        acc *= n-counter
        counter += 1

    if flag:
        print("%d divides %d!" % (case[1],case[0]))
    else:
        print("%d does not divide %d!" % (case[1],case[0]))

    try:
        case = list(map(int,input().split()))
    except:
        break