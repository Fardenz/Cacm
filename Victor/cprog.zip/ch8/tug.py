def expand(state,data):
    yield (state[0]+data[state[2]],state[1],state[2]+1)
    yield (state[0],state[1]+data[state[2]],state[2]+1)

def is_valid(state,data):
    return state[2] <= len(data)

def is_final(state,data):
    return state[2] == len(data)

def evaluate(state,data):
    return abs(state[0]-state[1])

def bound(state,data):
    return max(0,evaluate(state,data)-prec[state[2]])

cases = int(input())
input()

for case in range(cases):
    n_weights = int(input())
    weights = []
    for w in range(n_weights):
        weights.append(int(input()))
    weights.sort()

    x = (
        sum([weights[i] for i in range(n_weights) if i%2 == 0]),
        sum([weights[i] for i in range(n_weights) if i%2 == 1]),
        n_weights)
    fx = evaluate(x,weights)

    queue = []
    queue.insert(0,(0,0,0))

    visited = set()

    prec = [sum(weights[i:])/(n_weights-i) for i in range(n_weights)]+[0]

    while queue != []:
        current = queue.pop()
        if current in visited:
            continue
        visited.add(current)
        if is_final(current, weights):
            ev = evaluate(current,weights)
            if ev < fx:
                x = current
                fx = ev
            continue
        bo = bound(current,weights)
        if is_valid(current,weights) and bo < fx:
            for s in expand(current,weights):
                queue.insert(0,s)

    if x[0] < x[1]:
        print("%d %d" % (x[0], x[1]))
    else:
        print("%d %d" % (x[1], x[0]))

    if case != cases-1:
        input()
        print()

