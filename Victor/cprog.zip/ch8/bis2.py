def pos(i):
    if (i & 1) == 1:
        return int(i/4) *2 + 1
    else:
        return int((i-1)/4) *2 + 2

n,k = list(map(int,input().split()))

while [n,k] != [0,0]:
    #print(n,k)
    if k == 0:
        print("1")
        n,k = list(map(int,input().split()))
        continue
    n2 = 2*n
    n2_2 = int((2*n-1)/2)
    
    matrix = [[0 for i in range(0,k+1)]
                 for j in range(0,n2)]

    for i in range(0,n2):
        matrix[i][0] = 1
    matrix[1][1] = 1
    for i in range(2,n*2):
        for j in range(1,k+1):
            matrix[i][j] = matrix[i-2][j] + matrix[i-2][j-1] * (pos(i)-j+1)
    #print(matrix)
    res = 0
    for j in range(0,k+1):
        res += matrix[n2-1][j] * matrix[n2-2][k-j]
    print(res)

    n,k = list(map(int,input().split()))