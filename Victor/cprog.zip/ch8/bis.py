def generate_positions():
    aux = len(state)
    if aux%2 == 0:
        yield n2_2
        for i in range(1,n2_2-int(abs(n2_2-aux))):
            yield n2_2+2*i
            #yield n2_2-2*i
    else:
        yield n2_2+1
        #yield n2_2-1
        for i in range(1,n2_2-1-int(abs(n2_2-aux))):
            yield n2_2+1+2*i
            #yield n2_2-1-2*i
    yield -(len(state)+1)

def backtrack():
    if str(state) in visited:
        return
    visited.add(str(state))
    #print(state,is_complete(),is_valid(),is_correct())
    if is_complete():
        if is_correct():
            #print(state,is_complete(),is_valid(),is_correct())
            yield 1
        return
    elif is_valid():
        print(list(map(str,generate_positions())))
        for position in generate_positions():
            state.append(position)
            if position == n2_2 or position < 0:
                r = sum([e for e in backtrack()])
                print(r)
                yield r
            else:
                r = 2*sum([e for e in backtrack()])
                print(r)
                yield r
            state.pop()
        
def is_valid():
    if state == []:
        return True
    return state[-1] not in state[:-1]

def is_correct():
    return sum(1 for p in state if p >= 0) == k and is_valid()

def is_complete():
    return len(state) == 2*n-1

n,k = list(map(int,input().split()))

while [n,k] != [0,0]:
    state = []
    visited = set()
    n2 = 2*n-1
    n2_2 = int(n2/2)
    #print(n,k)
    print(sum(s for s in backtrack()))

    n,k = list(map(int,input().split()))

'''elif is_valid():
        #print(list(map(str,generate_positions())))
        for position in generate_positions():
            state.append(position)
            for s in backtrack():
                yield 2*s
            state.pop()'''